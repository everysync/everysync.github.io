/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'lsicons\'">' + entity + '</span>' + html;
	}
	var icons = {
		'ficon-plus': '&#xf05d;',
		'ficon-cancel': '&#xe612;',
		'ficon-chat': '&#xe049;',
		'ficon-pencil': '&#xe611;',
		'ficon-1': '&#xe60b;',
		'ficon-12': '&#xe60c;',
		'ficon-13': '&#xe60d;',
		'ficon-14': '&#xe60e;',
		'ficon-15': '&#xe60f;',
		'ficon-16': '&#xe610;',
		'ficon-icon-search': '&#xe60a;',
		'ficon-icon-eye': '&#xe609;',
		'ficon-icon_arrow_up': '&#xe607;',
		'ficon-icon_arrow_down': '&#xe608;',
		'ficon-icon-7': '&#xe606;',
		'ficon-icon-1': '&#xe600;',
		'ficon-icon-2': '&#xe601;',
		'ficon-icon-3': '&#xe602;',
		'ficon-icon-4': '&#xe603;',
		'ficon-icon-5': '&#xe604;',
		'ficon-icon-6': '&#xe605;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/ficon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
